Using this data in your paper? please cite:

-------------------------------------------------------
Sun, J. (2017). World Aircraft Database [Data file]. 
Retrieved from http://junzis.com/adb/data 
-------------------------------------------------------

or

-------------------------------------------------------
@misc{Sun2017adb,
  author = {Sun, Junzi},
  year = 2017,
  title = {World Aircraft Database [Data file]},
  note = {Retrieved from http://junzis.com/adb/data}
}
-------------------------------------------------------


